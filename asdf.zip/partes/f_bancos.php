<script src="js/formularios.js"></script>
<form id="f_bancos" class="formularios">
<h3 class="titulo_form">Banco</h3>
    <div class="campo_form">
        <label class="label_width">Nombre del banco</label>
        <input type="text" name="nombre" class="text_mediano">
    </div>
    <div class="campo_form">
        <label class="label_width">No de Cuenta</label>
        <input type="text" name="cuenta" class="text_largo">
    </div>
    <div class="campo_form">
        <label class="label_width">CLABE</label>
        <input type="text" name="clabe" class="text_largo">
    </div>
    <div align="right">
        <input type="button" class="guardar_individual" value="GUARDAR" data-m="individual">
    </div>
</form>
<div align="right">
	<input type="button" class="volver" value="VOLVER">
</div>