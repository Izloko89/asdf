<script src="js/formularios.js"></script>
<form id="f_familias" class="formularios">
<h3 class="titulo_form">Familias</h3>
<div class="campo_form">
<label class="label_width">CLAVE</label>
<input type="text" name="clave" class="text_mediano requerido mayuscula">
</div>
<div class="campo_form">
<label class="label_width">Nombre de subfamilia</label>
<input type="text" name="nombre" class="text_mediano">
</div>
<div align="right">
        <input type="button" class="guardar_individual" value="GUARDAR" data-m="individual">
    </div>
</form>
<div align="right">
	<input type="button" class="volver" value="VOLVER">
</div>